# Xlabs-Launcher
my archived exe of the xlabs launcher

fuck activision for the takedown 


this is my exe that ive had for awhile now just wanted to share it and archive it here for anyone looking


[VirusTotal](https://www.virustotal.com/gui/file/5700e0c520ad8a232ef4783a1a96bd32132db01a137377aac872d094a6fe0cf1)
```
https://www.virustotal.com/gui/file/5700e0c520ad8a232ef4783a1a96bd32132db01a137377aac872d094a6fe0cf1
```

MD5 hash
```
a354f50a5826c056fe588dd1eaa1d3ba
```


Lets hope [Plutonium](https://plutonium.pw) survives
